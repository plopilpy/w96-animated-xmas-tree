w96.ui.DialogCreator.alert("Happy Holidays 2021 ! Thank you for installing my package.\n I hope you enjoy it, as it took quite some effort. Please reboot to load the addon properly. -Plopilpy :)");
